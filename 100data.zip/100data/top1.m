function [objective]=top1(nelx,nely,volfrac,penal,rmin,mu)
format long
if (nargin == 0)
       nelx = 30;    nely = 30;    volfrac = 0.5;    penal = 3.0;    rmin = 1.5; mu = 0.2;
end
tic
global COORD
MaxIter = 100;loop = 0;change = 1; length = 0.4;    width = 0.4;
x(1:nely,1:nelx) = volfrac;
COORD = zeros((nelx+1)*(nely+1),2);
for elx = 1:nelx+1
    for ely = 1:nely+1
        COORD((elx-1)*(nely+1)+ely,:) = [length*(elx-1)/nelx,width*(ely-1)/nely];
    end
end
% % START ITERATION
while  change > 0.01 && loop < MaxIter %
%     if loop>6 &&  all( abs(objective(end)-objective(end-5:end-1) ) < 0.0001*abs(objective(end)) )
%         break
%     end
    loop = loop + 1;
    xold = x;
    % FE-ANALYSIS
    [U]=FE(nelx,nely,x,penal,mu);
    c = 0.;
    n2 = (nely+1) +1;[KE,~] = STIFQ4(COORD,[1,n2,n2+1,2],mu);
    for ely = 1:nely
        for elx = 1:nelx
            n1 = (nely+1)*(elx-1)+ely;
            n2 = (nely+1)* elx +ely;
            Ue = U([2*n1-1;2*n1; 2*n2-1;2*n2; 2*n2+1;2*n2+2; 2*n1+1;2*n1+2],1);
          %  [KE,~] = STIFQ4(COORD,[n1,n2,n2+1,n1+1]);
            c = c + x(ely,elx)^penal*Ue'*KE*Ue;
            dc(ely,elx) = -penal*x(ely,elx)^(penal-1)*Ue'*KE*Ue;
        end
    end
    objective(loop) = c;
    [dc]   = check(nelx,nely,rmin,x,dc); % SENSITIVITY FILTERING
    [x]    = OC(nelx,nely,x,volfrac,dc);  % DESIGN UPDATE BY OC METHOD
    change = max(max(abs(x-xold)));
    % PRINT RESULTS
    disp([' It.: ' sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',c) ...
        ' Vol.: ' sprintf('%6.3f',sum(sum(x))/(nelx*nely)) ...
        ' ch.: ' sprintf('%6.3f',change )])
    colormap(gray); imagesc(-x); axis equal; axis tight; axis off;pause(1e-6);
end
toc
cd([num2str(volfrac),'/'])
save(['obj',num2str(mu*10),'.mat'],'objective')
save(['rho',num2str(mu*10),'.mat'],'x')
saveas(gcf,['topCanti',num2str(mu*10),'.eps'])
saveas(gcf,['topCanti',num2str(mu*10),'.jpg'])
cd('..')
  %%%%%%%%%% FE-ANALYSIS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [U]=FE(nelx,nely,x,penal,mu)
bc = 2;
global COORD
n2 = (nely+1) +1;[KE,~] = STIFQ4(COORD,[1,n2,n2+1,2],mu);
K = sparse(2*(nelx+1)*(nely+1), 2*(nelx+1)*(nely+1));
F = sparse(2*(nely+1)*(nelx+1),1); U = zeros(2*(nely+1)*(nelx+1),1);
for elx = 1:nelx
    for ely = 1:nely
        n1 = (nely+1)*(elx-1)+ely;
        n2 = (nely+1)* elx   +ely;
        edof = [2*n1-1; 2*n1; 2*n2-1; 2*n2; 2*n2+1; 2*n2+2; 2*n1+1; 2*n1+2];
      %  [KE,~] = STIFQ4(COORD,[n1,n2,n2+1,n1+1]);
        K(edof,edof) = K(edof,edof) + x(ely,elx)^penal*KE;
    end
end
% DEFINE LOADS AND SUPPORTS (HALF MBB-BEAM)
switch bc
    case (1)
        F(2,1) = 1;
        fixeddofs   = union([1:2:2*(nely+1)],[2*(nelx+1)*(nely+1),]);
        alldofs     = [1:2*(nely+1)*(nelx+1)];
        freedofs    = setdiff(alldofs,fixeddofs);
    case (2)
        F(2*(nelx+1)*(nely+1),1) = -1;
        fixeddofs = [1:2*(nely+1)];
        alldofs = [1:2*(nely+1)*(nelx+1)];
        freedofs = setdiff(alldofs,fixeddofs);
end
% SOLVING
U(freedofs,:) = K(freedofs,freedofs) \ F(freedofs,:);
U(fixeddofs,:)= 0;
%%%%%%%%%% MESH-INDEPENDENCY FILTER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dcn]=check(nelx,nely,rmin,x,dc)
dcn=zeros(nely,nelx);
for i = 1:nelx
    for j = 1:nely
        sum=0.0;
        for k = max(i-floor(rmin),1):min(i+floor(rmin),nelx)
            for l = max(j-floor(rmin),1):min(j+floor(rmin),nely)
                fac = rmin-sqrt((i-k)^2+(j-l)^2);
                sum = sum+max(0,fac);
                dcn(j,i) = dcn(j,i) + max(0,fac)*x(l,k)*dc(l,k);
            end
        end
        dcn(j,i) = dcn(j,i)/(x(j,i)*sum);
    end
end
%%%%%%%%%% OPTIMALITY CRITERIA UPDATE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xnew]=OC(nelx,nely,x,volfrac,dc)
l1 = 0; l2 = 100000; move = 0.2;
while (l2-l1 > 1e-4)
    lmid = 0.5*(l2+l1);
    xnew = max(0.001,max(x-move,min(1.,min(x+move,(x.*sqrt(-dc./lmid)))))); % UPDATING NEW X VARIABLE BY GRAY SCALE FILTER
    if sum(sum(xnew)) > volfrac*nelx*nely  % UPDATING LAGRANGIAN MULTIPLIER USING BI SECTION METHOD
        l1 = lmid;
    else
        l2 = lmid;
    end
end
%%%Element Stiffness
function [K,M] = STIFQ4(Coord,NodeCon,mu)
K=zeros(8);
M=K;
YM = 1;
%mu = 0.3;
rho = 1;
thk = 1;
% % plane stress condition
% Dmat = YM/(1-mu^2)*[1,mu,0;mu,1,0;0,0,(1-mu)/2];
%plane strain condition
Dmat = YM/((1+mu)*(1-2*mu))*[1-mu mu 0;mu 1-mu 0;0 0 0.5-mu];
val=1/sqrt(3);
GQ=[val,val;val,-val;-val,val;-val,-val];
x=Coord(NodeCon,1);
y=Coord(NodeCon,2);
for gp=1:4
    Xi=GQ(gp,1);eta=GQ(gp,2);
    N1=0.25*(1-Xi)*(1-eta);
    N2=0.25*(1+Xi)*(1-eta);
    N3=0.25*(1+Xi)*(1+eta);
    N4=0.25*(1-Xi)*(1+eta);
    N=[N1 0 N2 0 N3 0 N4 0;0 N1 0 N2 0 N3 0 N4];
    J=0.25*[-(1-eta) (1-eta) (1+eta) -(1+eta);-(1-Xi) -(1+Xi) (1+Xi) (1-Xi)]*[x(1) y(1);x(2) y(2);x(3) y(3);x(4) y(4)];
    DJ=det(J);
    inJ=inv(J);
    R1=[1 0 0 0;0 0 0 1;0 1 1 0];
    R2=[inJ,zeros(2);zeros(2),inJ];
    R3=0.25*[-(1-eta) 0 (1-eta) 0 (1 + eta) 0 -(1 + eta) 0;
        -(1-Xi) 0 -(1 +Xi) 0 (1 + Xi) 0 (1-Xi) 0;
        0 -(1-eta) 0 (1-eta) 0 (1 + eta) 0 -(1 + eta);
        0 -(1-Xi) 0 -(1 +Xi) 0 (1 + Xi) 0 (1-Xi) ];
    B=R1*R2*R3;
    K=K+transpose(B)*Dmat*B*thk*DJ;
    M=M+transpose(N)*N*rho*thk*DJ;
end