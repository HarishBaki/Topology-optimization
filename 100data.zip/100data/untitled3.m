clc
clear all
close all
for vf = 0.1:0.1:0.9
    %mkdir(num2str(vf))
    for i = 0:0.01:0.09
    top1(100,100,vf,3.0,1.5,i)
    end
end